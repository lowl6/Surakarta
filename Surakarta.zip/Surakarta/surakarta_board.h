#pragma once
// #include <memory>
// #include <vector>
#include <QPainter>
#include "surakarta_piece.h"
#include <QWidget>
#define BOARD_SIZE 6
class SurakartaBoard : public QWidget{
    Q_OBJECT
public:
    explicit SurakartaBoard(QWidget *parent = 0);
    int cell_width=50;             //格子宽度
    int  piece_radius=cell_width/2;// r棋子的半径,格子一半的宽度
    int _selectid=-1;              // 被选中的棋子
    bool isBlackTurn;              // 是否轮到黑方走
    void initBoard();
    inline QPoint center(unsigned int row,unsigned int col);
    inline QPoint center(int id);
    bool IsInside(const SurakartaPosition& position) const {
        return position.x < BOARD_SIZE && position.y < BOARD_SIZE;
    }
    void paintEvent(QPaintEvent *);
    //与显示到窗口中有关的函数
    // void drawStone(QPainter& painter,int id);
    // //输入行列坐标 返回像素坐标
    // QPoint center(int row,int col);
    // //输入棋子的id 返回像素坐标
    // QPoint center(int id);
    SurakartaPiece piece[24];

};
inline QPoint SurakartaBoard::center(unsigned int x,unsigned int y)
{
    QPoint ret;
    ret.rx()=2*cell_width+x*cell_width;
    ret.ry()=2*cell_width+y*cell_width;
    return ret;
}
inline QPoint SurakartaBoard::center(int id)
{
    return center( piece[id].position_.x,piece[id].position_.y);
}
void SurakartaBoard::drawPiece(QPainter & painter, int id)
{
    if(piece[id].color_==PieceColor::NONE)
        return;
    // QRect rect = QRect(c.x()-_r,c.y()-_r,_r*2,_r*2);
    if(id==_selectid){
        painter.setBrush(Qt::cyan);
        painter.drawEllipse(center(id),piece_radius,piece_radius);
    }
    else{
        if(piece[id].color_==PieceColor::WHITE){
            painter.setBrush(Qt::white);
            painter.drawEllipse(center(id),piece_radius,piece_radius);
        }
        else if(piece[id].color_==PieceColor::BLACK){
            painter.setBrush(Qt::black);
            painter.drawEllipse(center(id),piece_radius,piece_radius);
        }
    }

}
void SurakartaBoard::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    int d=40;
    // 画10条横线
    _r = d/2;
    for(int i=1;i<=10;i++)
    {
        painter.drawLine(QPoint(d, i*d),QPoint(9*d,i*d));
    }

    for(int i=1;i<=9;i++)
    {
        if(i==1 || i==9)
            painter.drawLine(QPoint(i*d,d),QPoint(i*d,10*d));
        else
        {
            painter.drawLine(QPoint(i*d,d),QPoint(i*d,5*d));
            painter.drawLine(QPoint(i*d,6*d),QPoint(i*d,10*d));
        }

    }

    // 九宫格斜线
    painter.drawLine(QPoint(4*d,1*d),QPoint(6*d,3*d));
    painter.drawLine(QPoint(6*d,1*d),QPoint(4*d,3*d));
    painter.drawLine(QPoint(4*d,8*d),QPoint(6*d,10*d));
    painter.drawLine(QPoint(6*d,8*d),QPoint(4*d,10*d));


    // 绘制32个棋子
    for(int i=0;i<32;i++)
    {
        drawpiece(painter,i);
    }

}
inline void initBoard(SurakartaBoard)
{
    for(int i=0;i<24;i++)
    {
        inipiece(i);
    }
}
